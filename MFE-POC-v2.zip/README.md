# mfe-poc
MicroForntend POC
