export interface User {
    name: string;
    email: string;
  }
  
  export interface GlobalState {
    user: User | null;
    setUser: (user: User) => void;
  }