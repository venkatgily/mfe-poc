// import React from "react";
// import ReactDOM from "react-dom";
// import Footer from "./Footer";

// ReactDOM.render(<Footer />, document.getElementById("root"));
import("./Footer");