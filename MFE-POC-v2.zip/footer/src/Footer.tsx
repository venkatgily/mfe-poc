import React from "react";
import './Footer.css'; 
import { useGlobalStore } from "shell/store";
import type { GlobalState } from "@shared/types";

const Footer = () => {
    const user = useGlobalStore((state: GlobalState) => state.user);
    return (
        <footer>
            <p>Footer MFE {user.name}</p>
        </footer>
    )
}

export default Footer;