import React from "react";
import "./Header.css";
import { useGlobalStore } from "shell/store";
import type { GlobalState } from "@shared/types";

const Header = () => {

    const user = useGlobalStore((state: GlobalState) => state.user);
    const setUser = useGlobalStore((state: GlobalState) => state.setUser);

    const handleSetUser = () => {
        console.log("handleSetUser");
        setUser({name: "MFE User", email: "test@test.com"});
    }

    return (
     <header>
        <h2>MFE POC</h2>
         <div>
            User: {user.name}
            <span style={{ borderRadius: "3px", cursor: "pointer", backgroundColor: "rgba(0, 0, 0, 0.5)", color: "#fff", padding: "5px 10px", display:"inline-block"}} onClick={() => handleSetUser() }>Set User</span>
         </div>
     </header>
    )
};
export default Header;
