import { create } from "zustand";

export interface User {
    name: string;
    email: string;
  }

export interface GlobalState {
  user: User | null;
  setUser: (user: User) => void;
}

export const useGlobalStore = create<GlobalState>((set) => ({
  user: {name:"Venkat", email: "Venkat@example.com"},
  setUser: (user) => set({ user }),
}));
