import React from 'react';
import './card.css';

type CardType = {
   title: string;
   body: String;  
}

const Card = ({title, body}:CardType) => {

    return (
        <div className="card-wrapper">
            <h2 className="card-title">{title}</h2>
            <p className="card-content">{body}</p>
        </div>
    )
}

export default Card;
