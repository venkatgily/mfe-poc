import React, { useState, useEffect } from 'react';
import "./image-slider.css";

const images: string[] = [
    'https://picsum.photos/id/1015/600/400',
    'https://picsum.photos/id/1016/600/400',
    'https://picsum.photos/id/1018/600/400',
  ];

const ImageSlider = () => {
   
   const [currentIndex, setCurrentIndex] = useState<number>(0);

   useEffect(()=> {

    const imageSetTimeOut = setInterval(() => {
         setCurrentIndex((prevIndex)=> (prevIndex + 1) % images.length);                       
    }, 3000);
     
    return () => {
        clearInterval(imageSetTimeOut)    
    }

   }, [])

   const nextSlide = () => {
     setCurrentIndex((prevIndex)=> (prevIndex + 1) % images.length);
   }

   const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length)
   }


   return (
      <div className="slider-container">
         <button onClick={prevSlide} className="prev-btn">Previous</button> 
         <img src={images[currentIndex]} alt={`slide ${currentIndex + 1}`} className="slider-image" />
         <button onClick={nextSlide} className="next-btn">Next</button>
      </div>       
   )

}

export default ImageSlider;
