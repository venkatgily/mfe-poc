export interface User {
    name: string;
    email: string;
  }
  
  export interface UserSlice {
    user: User | null;
    setUser: (user: User) => void;
  }
  
  export type ThemeMode = "light" | "dark";
  
  export interface ThemeSlice {
    theme: ThemeMode;
    toggleTheme: () => void;
  }
  