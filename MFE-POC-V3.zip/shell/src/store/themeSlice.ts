import { StateCreator } from "zustand";
import { ThemeSlice } from "./types";

export const createThemeSlice: StateCreator<ThemeSlice, [], [], ThemeSlice> = (set, get) => ({
  theme: "light",
  toggleTheme: () => {
    const current = get().theme;
    set({ theme: current === "light" ? "dark" : "light" });
  },
});
