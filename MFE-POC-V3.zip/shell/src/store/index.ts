import { create } from "zustand";
import { createUserSlice } from "./userSlice";
import { createThemeSlice } from "./themeSlice";
import { UserSlice, ThemeSlice } from "./types";

type StoreState = UserSlice & ThemeSlice;

export const useGlobalStore = create<StoreState>()((...a) => ({
  ...createUserSlice(...a),
  ...createThemeSlice(...a),
}));
