import { StateCreator } from "zustand";
import { UserSlice, User } from "./types";

export const createUserSlice: StateCreator<UserSlice, [], [], UserSlice> = (set) => ({
  user: { name: "React User", email: "venkat.net7@gmail.com" },
  setUser: (user: User) => set({ user }),
});
