import React, { Suspense, useEffect, useState } from "react";
import ImageSlider from './components/image-slider/image-slider';
import Card from  './components/card/card';
import "./App.css";

const Header = React.lazy<React.FC>(() => import("header/Header"));
const Footer = React.lazy<React.FC>(() => import("footer/Footer"));

type Posts = {
    title: string;
    body: string;
}

const App = () => {

  const [posts, setPosts] = useState<Posts[]>([]);

  const fetchData = async () => {
    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/posts");
      // const response = await fetch("http://localhost:3003");
      const result  = await response.json();
      setPosts(result);
      console.log(result);
    } catch(error) {
       console.error(error);
    }
  }

  useEffect(() => {
    fetchData();
  }, [])


  return (
  <div>
    <Suspense fallback={<div>Loading Header...</div>}>
      <Header />
    </Suspense>
    <h1 style={{textAlign: "center"}}>Welcome to the Shell</h1>
    <div>
     <ImageSlider />
    </div>
    <div className="card-container">
       {
        posts.map((post) => (
          <Card title={post.title} body={post.body}  />
        ))
       }  
    </div>
    <Suspense fallback={<div>Loading Footer...</div>}>
      <Footer />
    </Suspense>
  </div>
  );
}

export default App;
