import React from "react";
import "./Header.css";
import { useGlobalStore } from "shell/store";
import type { UserSlice } from "@shared/types";

const Header = () => {

    const user = useGlobalStore((state: UserSlice) => state.user);
    const setUser = useGlobalStore((state: UserSlice) => state.setUser);

    const handleSetUser = () => {
        console.log("handle Set User");
        setUser({...user, name: user.name + 1});
    }

    return (
     <header>
        <h2>MFE POC</h2>
         <div>
            User: {user.name}
            <span style={{ borderRadius: "3px", cursor: "pointer", backgroundColor: "rgba(0, 0, 0, 0.5)", color: "#fff", padding: "5px 10px", display:"inline-block"}} onClick={() => handleSetUser() }>Set User</span>
         </div>
     </header>
    )
};
export default Header;
