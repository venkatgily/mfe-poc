import React from "react";
import ReactDOM from "react-dom";
import Header from "./Header";

ReactDOM.render(<Header />, document.getElementById("root"));
// import("./Header");