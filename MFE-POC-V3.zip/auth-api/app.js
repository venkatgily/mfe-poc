import express from 'express'; // Use import syntax
const app = express();
const port = 3003;

// Route that sends "Hello, World!" as a response
app.get('/', (req, res) => {
  res.send('Hello, World!');
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
